import React from 'react';
import styled from 'styled-components';
import Header from '../Main/Header';
import Title from '../../components/Text/Title';
import UserImg from '../../components/Layout/UserImg';
import UserProfile from '../../components/Layout/UserProfile';
import Slide from '../../components/Slide/Slide';
import Bold from '../../components/Text/Bold';
import Footer from '../Main/Footer';
import CommentSlides from"../../components/Slide/CommentSlides";
import Favorites from '../../components/Slide/Favorites';
import MyReviews from '../../components/Slide/MyReviews';
import { useState, useEffect} from 'react';
import axios from 'axios';




const MyPageWrap = styled.div`
  width:99vw;
  height:auto;
  .mypage-title{
    margin:5vh 0;
  }
  .slide-wrap{
    width:100%;
    margin:10vh 0 ;  
    .slide-title-wrap{
      width:65%;
      margin: auto;
      display:flex;
      flex-direction:row;
      align-items:center;
      padding-bottom:4vh;
      b{
        text-align:left;
        float:left;
        margin:0 1vw;
      }
      hr{
        width:85%;
        border:none;
        height:1.5px;
        background:#9CD5C2;
      }
    }
  }
`;

const ProfileWrap = styled.div`{

  width:50%;
  height:auto;
  margin:0 auto;
  display:flex;
  flex-direction:row;
  justify-content: center;

  .user-img-wrap{
    width:50%;
    display:flex;
    flex-direction:row;
    align-items:center;
    justify-content:center;
  }
  input{
    font-size:16px;
    text-align:left;
    margin-bottom:1vh;
  }
}

`;


// const Login = () => {
function Login () {

  const [users, setUsers] = useState([]);
  const [userReview, setUserReview] = useState([]);
  const [userComment, setUserComment] = useState([]);
  const [userCart, setUserCart] = useState([]);


 
  // const [hasError, setHasError] = useState(false);

  // useEffect(() => {
  //     fetch('http://localhost:8000/mypageInfo')
  //        .then(response =>response.json())
  //        .then(res => setUsers(res))
  //        .catch(err => setHasError(true))
  // },[]);

  useEffect(() => {
    axios.get('http://localhost:8000/mypageInfo')
         .then(res =>{
            //나의정보
            setUsers(res.data.mypageInfo);
            console.log(res.data.mypageInfo);
            //나의 리뷰
            setUserReview(res.data.mypageReview);
            console.log(res.data.mypageReview);
            //나의 댓글
            setUserComment(res.data.mypageComment);
            console.log(res.data.mypageComment);
            //찜하기
            setUserCart(res.data.mypageCart);
            console.log(res.data.mypageCart);
         })
         .catch(err => console.log(err))
  },[]);

  
  return (
      
    <>
    {/* {users.map(user => <h1 key={user}>{user.user_email}</h1>)} */}
    {/* {users && users.map(user => <h1 key={user}>{user.user_email}</h1>)} */}
    <MyPageWrap>
      <Header></Header>
        <Title className="mypage-title"></Title>
      <ProfileWrap>
        <div className='user-img-wrap'>
          <UserImg>1</UserImg>
        </div>  
        {/* 내정보 */}
        {/* <UserProfile name="손흥민" nickname="sonny" email="abc@abc.com" num="010-1111-1111"></UserProfile> */}
        {users.map(user => 
        <div key={user}>
        <UserProfile name={user.user_name} nickname={user.user_nickname} email={user.user_email} num={user.user_phonenumber}></UserProfile>
        </div>
        )}
        {/* 내정보 */}
      </ProfileWrap>
      <div className="slide-wrap">
        <div className='slide-title-wrap'>
          <Bold>내가 쓴 리뷰</Bold>
          <hr></hr>
        </div>
        {/* 내리뷰 */}
        <div className='review'>
        {userReview.map(review => 
        <div key={review}>
          상점명: {review.shop_name}<p></p>
          상점소개글: {review.field}<p></p>
          상점등록일시: {review.reg_dtm}<p></p>
          도로명주소: {review.shop_addr}<p></p>
        </div>
        )}
        {/* 내리뷰 */}

        </div>
        {/* <MyReviews></MyReviews> */}
      </div>
      <div className="slide-wrap">
        <div className='slide-title-wrap'>
          <Bold>내가 쓴 댓글</Bold>
          <hr></hr>
          
        </div>
        {/* 내댓글 */}
        <div className='comment'>
        {userComment.map(comment => 
        <div key={comment}>
          상점명: {comment.shop_name}<p></p>
          내가쓴 댓글: {comment.contents}<p></p>
          점수: {comment.score}<p></p>
          도로명주소: {comment.shop_addr}<p></p>
        </div>
        )}
        {/* 내댓글 */}

        </div>
        {/* <CommentSlides></CommentSlides> */}
        
      </div>
      <div className="slide-wrap">
        <div className='slide-title-wrap'>
          <Bold>내가 찜한 곳</Bold>
          <hr></hr>
        </div>
        {/* 찜하기 */}
        <div className='cart'>
        {userCart.map(cart => 
        <div key={cart}>
          상점명: {cart.shop_name}<p></p>
          도로명주소: {cart.shop_addr}<p></p>
          전화번호: {cart.telno}<p></p>
        </div>
        )}
        {/* 찜하기 */}
        </div>
        {/* <Favorites></Favorites> */}
      </div>
    <Footer></Footer>
    </MyPageWrap>
    
</>
  );
};

export default Login;
