// src/Login.jsx
import React from 'react';
import '../../scss/login-scss/login.scss'
import { useNavigate } from "react-router-dom";

const Login = () => {
  let kakaoLogin = () =>{
    alert('카카오 로그인!');
  }
  let idLogin = () =>{
    alert('아직 준비중입니다!');
  }

  const navigate = useNavigate();
  let goHome = () =>{
    navigate("/");
  }
  return (
    <>
      <div className='login-container'>
        <h2 className='logo'>Logo</h2>
        <div className='login-wrap'>
          <button className='kakao-login-btn' onClick={kakaoLogin}>
            <div className="kakao-logo"></div>
            <div className="kakao-text">카카오로 시작하기</div>
            </button>
          <button className='id-login-btn'onClick={idLogin}>아이디로 시작하기</button>
        </div>
        <div className='back-home-wrap'>
          <button href="/" className='back-home'onClick={goHome}>그냥 볼래요!</button>
        </div>
      </div>
    </>
  );
};

export default Login;
