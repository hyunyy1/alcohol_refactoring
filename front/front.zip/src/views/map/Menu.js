import '../../scss/map-scss/menu.scss'


function Menu(){
  function val(e){
    e.preventDefault();
    let text = document.getElementById('text');
    console.log(text.value);
    return false;
  }
  function selectEvent(e){
    let selVal = document.querySelector('option');
    console.log(e.value);
    console.log(selVal);
    console.log(e.options[e.selectedIndex].text);
  }
  return(
    <div className='menu-wrap'>
      <div className='logo'>
        logo
      </div>
      <div className='sel'>
        <select name="selectBottle" className="bottle-select" onChange={selectEvent}>
          <option value="" selected disabled>주종을 선택하세요.</option>
          <option value="dog">와인🍷</option>
          <option value="cat">맥주</option>
          <option value="hamster">소주🥛</option>
          <option value="parrot">칵테일🍹</option>
          <option value="spider">막걸리</option>
        </select>
      </div>

      <form id="form" onSubmit={val}>
        <input type="text" id="text"></input>
        <input type="submit" id="submit"></input>
      </form>
    </div>
    
  );
}

export default Menu;
