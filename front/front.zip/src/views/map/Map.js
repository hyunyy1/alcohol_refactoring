// src/Login.jsx
import React from 'react';
import '../../scss/map-scss/map.scss'
import Menu from './Menu';

const Map = () => {
  return (
    <div className='map-container'>
      <Menu />
      <div className='map'>
      map
      </div>
    </div>
  );
};

export default Map;
