import '../../scss/main-scss/Section3.scss';
import S3Card from './main-component/S3Card/S3Card';

function Section3() {
  let store = "애국가";
  let test = "서울시 강남구 어쩌구 저쩌구 123-123";
  let comment = "동해물과 백두산이 마르고 닳도록 하느님이 보우하사 우리 나라 만세 무궁화 삼천리 화려강산 대한 사람 대한으로...";
  return (
    <div className="container section3">
      <div className="s3-wrap">
        <h3 className='title'>최근 작성된 <span>리뷰</span></h3>
        <ul className='card-wrap'>
          <S3Card title={store} addr={test} review={comment}></S3Card>
          <S3Card title={store} addr={test} review={comment}></S3Card>
          <S3Card title={store} addr={test} review={comment}></S3Card>
        </ul>
      </div>
    </div>
  );
}

export default Section3;
