import '../../scss/main-scss/header.scss';

function Header() {
  function moveMypage(){
    alert('로그인 하세요!');
  }
  return (
    <div className="container">
      <header className="header">
        <a href='/'><span>LOGO</span></a>
        <div className='menu'>
        <a href="/login" className="login-link">Login</a>
        <a href="/mypage" onClick={moveMypage} className="mypage-link" target="_blank">My Page</a>
        </div>
      </header>
    </div>
  );
}

export default Header;
