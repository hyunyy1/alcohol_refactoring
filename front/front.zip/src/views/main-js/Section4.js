import '../../scss/main-scss/Section4.scss';
import S4Card from './main-component/S4Card/S4Card';

function Section4() {
  return (
    <div className="container section4">
      <div className="s4-wrap">
        <h3 className='title'>이 달의 <span>리뷰</span></h3>
        <ul className='card-wrap'>
            <S4Card userName="루피"></S4Card>
            <S4Card userName="탄지로"></S4Card>
            <S4Card userName="나루토"></S4Card>
            <S4Card userName="신드라"></S4Card>
        </ul>
        
      </div>
    </div>
  );
}

export default Section4;
