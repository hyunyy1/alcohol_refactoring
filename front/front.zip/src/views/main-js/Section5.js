import '../../scss/main-scss/Section5.scss';
import S5Card from './main-component/S5Card/S5Card';

function Section5() {
  let postDate = "2022.12.02"
  let comment = "소월을 말해봐 네 마음 속에 있는 작은 꿈을 말해봐 네 머리에 있는 이상형을 그려봐 그리고 나를 봐 난 너의 지니야 꿈이야 지니야 드림카를 타고 달려봐 너는 내 옆 자리에 앉아 그저 내 이끌림 속에 너를 던져 가슴 벅차 터져버려도 바람 결에 날려버려도 지금 이 순간 세상은 너의 것"
  return (
    <div className="container section5">
      <div className="s5-wrap">
        <h3 className='title'>에디터 추천 <span>술집</span></h3>
        <ul className='card-wrap'>
        <S5Card editorName="소녀시대" date={postDate} post={comment} />
        <S5Card editorName="데이식스" date={postDate} post={comment} />
        <S5Card editorName="아이유" date={postDate} post={comment} />
        <S5Card editorName="윤하" date={postDate} post={comment} /> 
        </ul>
        
      </div>
    </div>
  );
}

export default Section5;
