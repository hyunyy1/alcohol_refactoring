import '../../scss/main-scss/Section1.scss';
import { useNavigate } from "react-router-dom";

function Section1() {

  const navigate = useNavigate();
  let find = () =>{
    navigate("/map");
  }  
  return (
    <div className="container section1">
      <div className="s1-wrap">
        <h3>안녕하세요. <span>userName</span>님!</h3>
        <h4>오늘은 시원한 맥주 추천드려요!</h4>
        <input type="text" placeholder="검색어를 입력하세요." onSubmit={search}></input>
        <p></p>
        <div className="btn-wrap">
          <button onClick={find}>내 주변 술집 찾기</button>
          <button onClick={MoveToReview}>리뷰 쓰러 가기</button>
        </div>
      </div>
    </div>
  ); 
}
function search(){

  alert('검색');
}

let MoveToReview = () => {
  alert('리뷰 쓰러 가기');
}

export default Section1;
