import React from "react";
import Slider from "react-slick";
import './S3slide.scss';

function S3slidecard(){
  function moveReview(){
    alert('최근 작성된 리뷰 보러가기')
  }
  return(
    <div className="card">
      <h4 className="title">술집 이름</h4>
      <p className="addr">서울시 강남구 어쩌구 저저구 122-122</p>
      <div className="review">느낌이 오잖아 떨리고 있잖아 언제까지 눈치만 볼거니 네 맘을 말해봐 망설이지 말란 말이야 </div>
      <div className="btn-wrap">
        <button className="btn" onClick={moveReview}>보러가기</button>
      </div>
    </div>
  );
}
export default S3slidecard;
