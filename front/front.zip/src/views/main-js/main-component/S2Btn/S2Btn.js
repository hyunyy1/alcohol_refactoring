import '../../../../scss/main-scss/Section2.scss';


function S2Btn(props) {
  return (
    <>
      <button onClick={s2select} className="select">{props.name}</button>
    </>
  );
  function s2select(){
    alert(props.name);
  }  
}


export default S2Btn;
