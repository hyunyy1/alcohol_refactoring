import React from "react";
import Slider from "react-slick";
import './S4slide.scss';
import S4Slidebutton from "./S4slidebutton";

class S4Slide extends React.Component {
  render() {
    var settings = {
      dots: false,
      infinite: true,
      speed: 500,
      slidesToShow: 1,
      slidesToScroll: 1,
      autoplay: false,
      autoplaySpeed: 2500,
      // 화면에 올리면 슬라이더가 자동으로 넘어가지 않음
      pauseOnHover: true,
    };
    return (
      <Slider {...settings} className="Slider-s4">
        <div className="ranking-wrap">
          <div className="card-wrap">
            <S4Slidebutton />
            <S4Slidebutton />
            <S4Slidebutton />
            <S4Slidebutton />
          </div>
        </div>
        <div className="ranking-wrap">
          <div className="card-wrap">
            <S4Slidebutton />
            <S4Slidebutton />
            <S4Slidebutton />
            <S4Slidebutton />
          </div>
        </div>
        <div className="ranking-wrap">
          <div className="card-wrap">
            <S4Slidebutton />
            <S4Slidebutton />
            <S4Slidebutton />
            <S4Slidebutton />
          </div>
        </div>
        <div className="ranking-wrap">
          <div className="card-wrap">
            <S4Slidebutton />
            <S4Slidebutton />
            <S4Slidebutton />
            <S4Slidebutton />
          </div>
        </div>

      </Slider>
    );
  }
}
export default S4Slide;
