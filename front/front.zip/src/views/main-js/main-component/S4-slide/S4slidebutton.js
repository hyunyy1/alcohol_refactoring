import React from "react";
import Slider from "react-slick";
import './S4slide.scss';

function S4Slidebutton(){
  let moveRank = () =>{
    alert('이 달의 리뷰 보러 가기')
  }
  return(
      <button className="rank" onClick={moveRank}>
        <div className="profile">
          <div className="userImg"></div>
          <div className="userId">userId</div>
          <div className="recommend">1234</div>
        </div>
        <hr></hr>
        <div className="tags">
          <div className="tag">와인🍷</div>
          <div className="tag">맥주🍺</div>
          <div className="tag">소주🥛</div>
        </div>
        <div className="storeName">술집 이름</div>
        <div className="comment">저기 사라진 별의 자리 아스라이 하얀 빛 한 동안은 꺼내 볼 수 있을거야. 아낌없이 반짝인 시간은 조금...</div>
      </button>
  
  );
}
export default S4Slidebutton;
