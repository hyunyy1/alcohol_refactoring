import '../../../../scss/main-scss/Section4.scss';


function S4Card(props) {
  return (
    
    <li className='card'>
              <button className="S4-btn" onClick={Month}>
                <div className="text-wrap">
                  <div className="profile">
                    <div className="userImg"></div>
                    <span className='userName'>{props.userName}</span>
                    <p className='recommend'>1111</p>
                  </div>
                  <hr></hr>
                  <div className="tag-wrap">
                    <div className='tag wine'>
                      <p>와인🍷</p>
                    </div>
                    <div className='tag beer'>
                      <p>맥주🍺</p>
                    </div>
                    <div className='tag cocktail'>
                      <p>칵테일🍹</p>
                    </div>
                  </div>
                  <div className="reviews">
                    <p className="reviews-title"><span>역전 할머니 맥주</span></p>
                    <p className="reviews-comment">여기 진짜 분위기 너무 좋아요.
일단 들어갈때 분위기에 취합니다.
안주 탄탄하고 분위기 좋은 술...</p>
                  </div>
                </div>
                </button>
            </li>

  );
  
}
let Month = () => {
  alert('이 달의 리뷰 보러가기')
}
export default S4Card;
