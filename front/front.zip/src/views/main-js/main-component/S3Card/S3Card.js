import '../../../../scss/main-scss/Section3.scss';

function S3Card(props) {
  return (
    <li>
    <p className='card-title'>{props.title}</p>
    <p className='card-addr'>{props.addr}</p>
    <p className='card-review'>{props.review}</p>
    <button className="move-review" onClick={MoveToReview}>보러가기</button>
  </li>
  );
  function MoveToReview(){
    alert('최근 작성된 리뷰 보러가기~')
  }
}

export default S3Card;
