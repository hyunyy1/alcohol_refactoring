import '../../../../scss/main-scss/Section5.scss';

function S5Card(props) {
  return (
    <li className='card'>
    <button onClick={editorPost} className="editor-btn">
      <div className="editor-wrap">
        <p className='editor-title'><span className='editor-name'>{props.editorName}</span>의 추천 술집</p>
        <p className='date'>{props.date}</p>
      </div>
      <p className="editor-text">{props.post}</p>
      <ul className='tags'>
        <li>#와인</li>
        <li>#와인</li>
        <li>#와인</li>
        <li>#와인</li>
        <li>#와인</li>
        <li>#와인</li>
      </ul>
    </button>
  </li>
  );
  function editorPost(){
    alert('에디터 추천 술집 보러가기')
  }
}

export default S5Card;
