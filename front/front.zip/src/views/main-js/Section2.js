import '../../scss/main-scss/Section2.scss';
import S2Btn from './main-component/S2Btn/S2Btn';


function Section2() {
  return (
    
    <div className="container section2">
      <div className="s2-wrap">
        <h3 className='title'>무슨 <span>술</span>이 땡기시나요?</h3>
        <div className="btn-wrap">
          <S2Btn name="와인🍷"></S2Btn>
          <S2Btn name="맥주🍺"></S2Btn>
          <S2Btn name="소주🥛"></S2Btn>
          <S2Btn name="칵테일🍹"></S2Btn>
          <S2Btn name="막걸리🍶"></S2Btn>
        </div>
      </div>
    </div>
  );
}

export default Section2;
