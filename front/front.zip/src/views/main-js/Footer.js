import '../../scss/main-scss/Footer.scss';

function Footer() {
  return (
    <div className="footer-wrap">
      <p className="sns">*SNS를 통해 업데이트 소식을 알려드립니다.</p>
      <p className="copy">Copyright ⓒ KOSTA_node_5th_team All rights reserved.</p>
      <div className="a-wrap">
        <a href="#">서비스 이용약관</a>
        <a href="#">개인정보처리방침</a>
      </div>
    </div>
  );
}

export default Footer;
