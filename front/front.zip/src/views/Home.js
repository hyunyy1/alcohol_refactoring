import '../scss/App.scss';
import Header from './main-js/Header.js';
import Section1 from './main-js/Section1.js';
import Section2 from './main-js/Section2.js';
import Section3 from './main-js/Section3.js';
import Section4 from './main-js/Section4.js';
import Section5 from './main-js/Section5.js';
import Footer from './main-js/Footer.js';

import S3Slide from './main-js/main-component/S3-slide/S3Slide';
import S4Slide from './main-js/main-component/S4-slide/S4slide';

function Home() {
  return (
    <>
      <Header></Header>
      <Section1></Section1>
      <Section2></Section2>
      <h2 className='newest-review'>최근 작성된 리뷰</h2>
      <S3Slide />
      <h2 className='monthly-review'>이 달의 리뷰</h2>
      <S4Slide />
      {/* <Section3></Section3> */}
      {/* <Section4></Section4> */}
      <Section5></Section5>
      <Footer></Footer>
    </>
  );
}

export default Home;
