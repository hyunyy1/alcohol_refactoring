import '../../scss/mypage-scss/Section2.scss';
import S2Card from './mypage-component/S2Card';

let Section2 = () => {
  return(
    <>
      <div className='review-container'>
        <div className='review-title'>
          <h4>내가 쓴 리뷰</h4>
          <hr></hr>
        </div>
        <ul className='review-wrap'>
          <S2Card />
          <S2Card />
          <S2Card />
        </ul>
      </div>
    </>
  );
}

export default Section2;
