import '../../../scss/mypage-scss/Section2.scss'

let S2Card = () => {
  return(
    <>      
      <li className='reviews'>
        <p className='store'>술집 이름</p>
        <p className='addr'>서울시 강남구 어쩌구 저쩌구 123-012</p>
        <p className='review'>저기 사라진 별의 자리 아스라이 하얀빛 한 동안은 꺼내 볼 수 있을 거야.</p>
        <button className='review-btn' onClick={revise}>수정하기</button>
      </li>
    </>
  );
  function revise(){
    alert('리뷰 수정하기!!')
  }
}

export default S2Card;
