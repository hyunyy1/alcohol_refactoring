import '../../../scss/mypage-scss/Section3.scss'

let S3Card = () => {
  return(
    <>      
      <li className='reviews'>
        <p className='store'>술집 이름</p>
        <p className='addr'>😍</p>
        <p className='review'>저기 사라진 별의 자리 아스라이 하얀빛 한 동안은 꺼내 볼 수 있을 거야.</p>
        <div className='btn'>
          <button className='revise-btn' onClick={revise}>수정</button>
          <button className='remove-btn' onClick={remove}>삭제</button>
        </div>
      </li>
    </>
  );
}
let revise = () =>{
  alert('리뷰를 수정 하시겠습니까?');
}

let remove = () =>{
  alert('리뷰를 삭제 하시겠습니까?');
}

export default S3Card;
