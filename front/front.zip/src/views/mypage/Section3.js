import '../../scss/mypage-scss/Section2.scss';
import S3Card from './mypage-component/S3Card';

let Section3 = () => {
  return(
    <>
      <div className='review-container'>
        <div className='review-title'>
          <h4>내가 쓴 댓글</h4>
          <hr></hr>
        </div>
        <ul className='review-wrap'>
          <S3Card />
          <S3Card />
          <S3Card />
        </ul>
      </div>
    </>
  );
}

export default Section3;
