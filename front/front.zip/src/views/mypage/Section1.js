import '../../scss/mypage-scss/Section1.scss'

let Section1 = () => {
  return(
    <>
      <div className='profile-container'>
        <h2>마이 페이지</h2>
        <div className='profile-wrap'>
          <div className='img-wrap'>
            <div className='img'></div>

          </div>
          <div className='text-wrap'>
            <h4>이름</h4>
            <div className='userName'>손흥민</div>
            <h4>닉네임</h4>
            <div className='nickName'>Sonny</div>
            <h4>이메일</h4>
            <div className='userMail'>email@email.com</div>
            <h4>전화번호</h4>
            <div className='userNum'>010-1234-0000</div>
            <div className='profile-btn-wrap'>
              <button className='resubmit-profile' onClick={reviseProfile}>프로필 수정</button>
              <button className='cancel'>취소</button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
let reviseProfile=()=>{
  alert('프로필 수정');
}

export default Section1;
