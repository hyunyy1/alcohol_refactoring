import '../../scss/mypage-scss/Section2.scss';
import S4Card from './mypage-component/S4Card';
import S3slide from './mypage-component/S3-slide/S3Slide';

let Section4 = () => {
  return(
    <>
      <div className='review-container'>
        <div className='review-title'>
          <h4>내가 찜한 곳</h4>
          <hr></hr>
        </div>
        <ul className='review-wrap'>
          <S3slide />
          {/* <S4Card />
          <S4Card />
          <S4Card /> */}
        </ul>
      </div>
    </>
  );
}

export default Section4;
