// src/App.jsx
import { Routes, Route } from "react-router-dom";
import Home from './views/Home';
import Login from './views/login/Login';
import Mypage from './views/mypage/Mypage';
import Map from './views/map/Map';

function App() {
  return (
    <Routes>
      <Route path='/' element={<Home />} />
      <Route path='/login' element={<Login />} />
      <Route path='/mypage' element={<Mypage />} />
      <Route path='/map' element={<Map />} />
    </Routes>
  );
}

export default App;
